<?php
$config['local'] = "Diamantino-MT";
