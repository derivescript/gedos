<?php
/*
|---------------------------------------------------------
| S.I.L.A.S - Um framework legal
| Autor: Daniel da Costa e Faria - danielcfaria@gmail.com
|---------------------------------------------------------
*/


/*
|---------------------------------------------------------
| Começando os trabalhos
|---------------------------------------------------------
*/
ini_set('display_errors','on');
ini_set('error_reporting', E_ALL);
define('br','<br>');
define('sisdir','sistema');
define('appdir','apps');
define('modeldir',appdir.'/models/');
require 'core/Silas.php';
