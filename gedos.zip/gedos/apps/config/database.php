<?php
$config['driver'] = 'mysql';
$config['name'] = "falconi";
$config['host'] = "localhost";
$config['porta'] = "3306";
$config['senha'] = "derive382it";
$config['usuario'] = "daniel";

