<?php
/**
 * 
 */
$autoload['bibliotecas'] = '';
/**
 * Quando importamos pastas com bibliotecas que possuem um autoload.php colocamos o nome da pasta na lista
 */
$autoload['pastas'] = '';
