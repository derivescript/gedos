<?php
//Nome do usuario do e-mail
$email['nome'] = 'Cepad Eventos';
// Endere�o do servidor SMTP (Autenticação, utilize o host smtp.seudom�nio.com.br)
$email['host']= 'smtp.cepad.net.br';
// Usar autenticação SMTP (obrigatório para smtp.seudom�nio.com.br)
$email['smtpauth']   = true;
// Porta de autenticacao do servidor smtp
$email['porta'] = 587;
// Endere�o do servidor pop3
$email['popserver']= 'pop.cepad.net.br';
// Porta de autenticacao do servidor pop
$email['portapop'] = 110;
// Endere�o do servidor imap
$email['imap_server']= 'imap.cepad.net.br';
// Porta de autenticacao do servidor imap
$email['porta_imap'] = 143;
// Usuario do email
$email['usuario'] = 'eventoscepad@cepad.net.br';
// Senha do email
$email['senha'] = 'tdjH9q22$@jsoaP';
