<?php

$param['timezone'] = 'America/Cuiaba';