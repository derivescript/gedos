<?php 
namespace apps\controllers; 

class DashboardController extends \core\Controller{
	public function index(){ 
		//Implementacao 
		$this->view('dashboard');
	}
}
	