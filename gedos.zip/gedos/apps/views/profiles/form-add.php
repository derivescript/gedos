<form action="profiles/save" method="post">
    <div class="card-body">
        <div class="col-6">
            <div class="row">
            <div class="form-group">
            <label for="nome">Nome</label>
            <input type="text" name="nome" id="nome" class="form-control" autocomplete="off">
        </div>
		
            </div>
        </div>
        <div class="col-6">
            <button type="submit" class="btn btn-success">Salvar</button>
            <button class="btn btn-primary" type="button" id="cancelButton">Cancelar</button>
        </div>
    </div>
</form>