<div class="card card-secondary">
    <div class="card-header">
    <h3 class="card-title">Filtros</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
    
    </div>
</div>

<div class="card card-secondary">
    <div class="card-header">
    <h3 class="card-title">Lista de documentos</h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
    {tabela}
    </div>
</div>