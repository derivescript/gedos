<div class="center">     
    <form action="documentos/updatestatus" method="post">
        <div class="row">
            <div class="col-sm-12">
                 {content}
            </div>        
        </div>
        <input type="hidden" name="id" id="id" value="{id}">
    </form>
</div>
